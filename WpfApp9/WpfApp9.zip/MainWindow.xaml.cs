﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace WpfApp9 {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {
        public MainWindow()
        {
            InitializeComponent();
            pointSeries.ArgumentDataMember = "Argument";
            pointSeries.ValueDataMember = "Value";

            pointSeries.DataSource = DataGenerator.Generate();

        }
    }

    public class DataRow {
        public double Argument { get; set; }
        public double Value { get; set; }
    }
    public class DataGenerator {
        public static List<DataRow> Generate()
        {
            List<DataRow> result = new List<DataRow>();
            for (double i = 0; i < 15000; i++)
            {
                double circleArg = Math.PI * 2 / 1000 * i;
                double circleAmp = 100 + i / 100;
                double x = circleAmp * Math.Cos(circleArg);
                double y = circleAmp *Math.Sin(circleArg);
                result.Add(new DataRow() { Argument = x, Value = y });
            }
            return result;
        }
    }
}
